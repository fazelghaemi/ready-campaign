<?php
if (!defined('ABSPATH')) { exit; }

class RCP_Admin {
    public static function init() {
        add_action('add_meta_boxes', [__CLASS__, 'add_metaboxes']);
        add_action('save_post', [__CLASS__, 'save_meta']);

        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets']);
        add_action('admin_menu', [__CLASS__, 'utm_builder_page']);
        add_action('admin_menu', [__CLASS__, 'dashboard_page'], 5);
        add_filter('manage_edit-' . RCP_Post_Type::CPT . '_columns', [__CLASS__, 'columns']);
        add_action('manage_' . RCP_Post_Type::CPT . '_posts_custom_column', [__CLASS__, 'column_content'], 10, 2);

        add_action('wp_ajax_rc_apply_utm_to_banner', [__CLASS__, 'ajax_apply_utm']);
    }

    public static function admin_assets($hook) {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || ($screen->post_type !== RCP_Post_Type::CPT && strpos($hook, 'page_rc-utm-builder') === false)) return;
        wp_enqueue_style('rc-admin', RCP_ASSETS_URL . 'css/ready-campaign.css', [], RCP_VERSION);
        wp_enqueue_script('rc-admin', RCP_ASSETS_URL . 'js/ready-campaign-admin.js', ['jquery'], RCP_VERSION, true);
        wp_localize_script('rc-admin', 'RCAdmin', [
            'nonce' => wp_create_nonce('rc_admin_nonce'),
            'applyUrl' => admin_url('admin-ajax.php?action=rc_apply_utm_to_banner')
        ]);
        wp_enqueue_media();
    }

    public static function add_metaboxes() {
        add_meta_box('rc_banner_settings', __('Banner Settings', 'ready-campaign'), [__CLASS__, 'metabox_render'], RCP_Post_Type::CPT, 'normal', 'high');
    }

    public static function dashboard_page() {
        add_submenu_page(
            'edit.php?post_type=' . RCP_Post_Type::CPT,
            __('Campaign Center', 'ready-campaign'),
            __('Campaign Center', 'ready-campaign'),
            'edit_posts',
            'rc-campaign-center',
            [__CLASS__, 'dashboard_render']
        );
    }

    public static function columns($columns) {
        return [
            'cb' => isset($columns['cb']) ? $columns['cb'] : '<input type="checkbox" />',
            'title' => __('Campaign name', 'ready-campaign'),
            'rc_status' => __('Status', 'ready-campaign'),
            'rc_devices' => __('Devices', 'ready-campaign'),
            'rc_schedule' => __('Schedule', 'ready-campaign'),
            'date' => __('Created', 'ready-campaign'),
        ];
    }

    public static function column_content($column, $post_id) {
        if ($column === 'rc_status') {
            $status = self::campaign_status($post_id);
            echo '<span class="rc-status rc-status-' . esc_attr($status['key']) . '"><i></i>' . esc_html($status['label']) . '</span>';
        } elseif ($column === 'rc_devices') {
            $device = get_post_meta($post_id, 'rc_device', true) ?: 'both';
            $labels = ['both' => 'دسکتاپ + موبایل', 'desktop' => 'دسکتاپ', 'mobile' => 'موبایل'];
            echo '<span class="rc-device-pill">' . esc_html($labels[$device] ?? $labels['both']) . '</span>';
        } elseif ($column === 'rc_schedule') {
            $start = get_post_meta($post_id, 'rc_start', true);
            $end = get_post_meta($post_id, 'rc_end', true);
            if (!$start && !$end) echo '<span class="rc-muted">همیشه</span>';
            else echo '<span class="rc-schedule">' . esc_html($start ?: 'بدون شروع') . '<br><small>' . esc_html($end ?: 'بدون پایان') . '</small></span>';
        }
    }

    private static function campaign_status($post_id) {
        if (get_post_status($post_id) !== 'publish') return ['key' => 'draft', 'label' => 'پیش‌نویس'];
        if (!get_post_meta($post_id, 'rc_active', true)) return ['key' => 'paused', 'label' => 'متوقف'];
        $now = current_time('timestamp', true);
        $start = get_post_meta($post_id, 'rc_start', true);
        $end = get_post_meta($post_id, 'rc_end', true);
        $to_ts = function($value) { try { return (new DateTime($value, wp_timezone()))->getTimestamp(); } catch (Exception $e) { return 0; } };
        if ($start && ($ts = $to_ts($start)) && $now < $ts) return ['key' => 'scheduled', 'label' => 'زمان‌بندی‌شده'];
        if ($end && ($ts = $to_ts($end)) && $now > $ts) return ['key' => 'ended', 'label' => 'پایان‌یافته'];
        return ['key' => 'live', 'label' => 'در حال اجرا'];
    }

    public static function dashboard_render() {
        if (!current_user_can('edit_posts')) return;
        $posts = get_posts(['post_type' => RCP_Post_Type::CPT, 'post_status' => 'any', 'numberposts' => 8, 'orderby' => 'date', 'order' => 'DESC']);
        $all = get_posts(['post_type' => RCP_Post_Type::CPT, 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids']);
        $stats = ['total' => count($all), 'live' => 0, 'scheduled' => 0, 'draft' => 0];
        foreach ($all as $id) { $s = self::campaign_status($id); if (isset($stats[$s['key']])) $stats[$s['key']]++; }
        $new_url = admin_url('post-new.php?post_type=' . RCP_Post_Type::CPT);
        $utm_url = admin_url('edit.php?post_type=' . RCP_Post_Type::CPT . '&page=rc-utm-builder');
        $analytics_url = admin_url('edit.php?post_type=' . RCP_Post_Type::CPT . '&page=rc-analytics');
        ?>
        <div class="wrap rc-admin-shell rc-center-page">
            <section class="rc-center-hero">
                <div class="rc-center-hero__copy"><span class="rc-eyebrow">READY CAMPAIGN · CONTROL ROOM</span><h1>مرکز فرمان کمپین</h1><p>از ساخت بنر تا اندازه‌گیری نتیجه، همه‌چیز را از یک مسیر روشن مدیریت کنید.</p><a class="button rc-cta" href="<?php echo esc_url($new_url); ?>">+ ساخت کمپین جدید</a></div>
                <div class="rc-center-orbit" aria-hidden="true"><span class="rc-orbit-dot dot-one"></span><span class="rc-orbit-dot dot-two"></span><span class="rc-orbit-core">RC</span></div>
            </section>
            <section class="rc-center-stats" aria-label="خلاصه کمپین‌ها">
                <div class="rc-center-stat"><span>همه کمپین‌ها</span><strong><?php echo number_format_i18n($stats['total']); ?></strong><small>ثبت‌شده در افزونه</small></div>
                <div class="rc-center-stat is-live"><span>در حال اجرا</span><strong><?php echo number_format_i18n($stats['live']); ?></strong><small>در حال نمایش به کاربران</small></div>
                <div class="rc-center-stat is-scheduled"><span>زمان‌بندی‌شده</span><strong><?php echo number_format_i18n($stats['scheduled']); ?></strong><small>آماده انتشار</small></div>
                <div class="rc-center-stat is-draft"><span>پیش‌نویس</span><strong><?php echo number_format_i18n($stats['draft']); ?></strong><small>نیازمند تکمیل</small></div>
            </section>
            <div class="rc-center-grid">
                <section class="ui-card rc-workflow-card"><div class="rc-card-heading"><div><span class="rc-card-kicker">مسیر پیشنهادی</span><h2>از ایده تا نتیجه</h2></div><span class="rc-card-icon">✦</span></div>
                    <div class="rc-workflow"><div class="rc-workflow-step is-done"><b>۰۱</b><div><strong>کمپین را تعریف کنید</strong><span>نام، تصویر و هدف کمپین را مشخص کنید.</span></div><i>✓</i></div><div class="rc-workflow-step"><b>۰۲</b><div><strong>لینک قابل‌اندازه‌گیری بسازید</strong><span>پارامترهای UTM را تکمیل کنید.</span></div><a href="<?php echo esc_url($utm_url); ?>">باز کردن</a></div><div class="rc-workflow-step"><b>۰۳</b><div><strong>نمایش را زمان‌بندی کنید</strong><span>دستگاه، موقعیت و زمان نمایش را تنظیم کنید.</span></div><span class="rc-step-note">در ویرایشگر</span></div><div class="rc-workflow-step"><b>۰۴</b><div><strong>نتیجه را بسنجید</strong><span>نمایش‌ها، کلیک‌ها و نرخ کلیک را بررسی کنید.</span></div><a href="<?php echo esc_url($analytics_url); ?>">گزارش‌ها</a></div></div>
                </section>
                <section class="ui-card rc-next-card"><span class="rc-card-kicker">شروع سریع</span><h2>قدم بعدی شما چیست؟</h2><p>یک مسیر را انتخاب کنید و کار را ادامه دهید.</p><a class="rc-next-action" href="<?php echo esc_url($new_url); ?>"><span>＋</span><div><strong>ساخت بنر جدید</strong><small>برای یک کمپین تازه</small></div><b>←</b></a><a class="rc-next-action" href="<?php echo esc_url($utm_url); ?>"><span>↗</span><div><strong>ساخت لینک UTM</strong><small>برای ردیابی دقیق‌تر</small></div><b>←</b></a></section>
            </div>
            <section class="ui-card rc-recent-card"><div class="rc-card-heading"><div><span class="rc-card-kicker">آخرین فعالیت</span><h2>کمپین‌های اخیر</h2></div><a href="<?php echo esc_url(admin_url('edit.php?post_type=' . RCP_Post_Type::CPT)); ?>">مشاهده همه ←</a></div>
                <?php if ($posts): ?><div class="rc-recent-list"><?php foreach ($posts as $post): $s = self::campaign_status($post->ID); ?><a class="rc-recent-row" href="<?php echo esc_url(get_edit_post_link($post->ID)); ?>"><span class="rc-recent-avatar"><?php echo esc_html(mb_strtoupper(mb_substr($post->post_title ?: 'ب', 0, 1))); ?></span><span class="rc-recent-name"><strong><?php echo esc_html($post->post_title ?: 'بدون عنوان'); ?></strong><small><?php echo esc_html(get_the_date('', $post)); ?></small></span><span class="rc-status rc-status-<?php echo esc_attr($s['key']); ?>"><i></i><?php echo esc_html($s['label']); ?></span><span class="rc-recent-arrow">←</span></a><?php endforeach; ?></div><?php else: ?><div class="rc-empty-state"><span>✦</span><strong>هنوز کمپینی ساخته نشده است</strong><p>اولین کمپین خود را بسازید و مسیر نمایش آن را کنترل کنید.</p><a class="button rc-cta" href="<?php echo esc_url($new_url); ?>">ساخت اولین کمپین</a></div><?php endif; ?>
            </section>
        </div>
        <?php
    }

    public static function field($name, $default='', $post_id=0) {
        $v = get_post_meta($post_id, $name, true);
        return ($v === '') ? $default : $v;
    }

    public static function metabox_render($post) {
        wp_nonce_field('rc_save_meta', 'rc_nonce');
        $id = $post->ID;

        $get = function($k,$d='') use ($id){ return esc_attr(self::field($k,$d,$id)); };
        $geti= function($k,$d=0) use ($id){ return (int)self::field($k,$d,$id); };
        $getb= function($k,$d=false) use ($id){ return (bool)self::field($k,$d,$id); };

        $imgD = (int)self::field('rc_image_desktop',0,$id);
        $imgM = (int)self::field('rc_image_mobile',0,$id);
        $imgDurl = $imgD ? wp_get_attachment_image_url($imgD,'full') : RCP_ASSETS_URL.'img/placeholder.svg';
        $imgMurl = $imgM ? wp_get_attachment_image_url($imgM,'full') : RCP_ASSETS_URL.'img/placeholder.svg';
?>
        <style>.rc-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.rc-row{margin-bottom:12px}</style>
        <div class="rc-admin-shell rc-banner-editor">
            <div class="rc-editor-intro">
                <span class="rc-eyebrow">READY CAMPAIGN · CAMPAIGN STUDIO</span>
                <h2>تنظیم و انتشار بنر</h2>
                <p>بنر، لینک مقصد و زمان نمایش را یک‌جا مدیریت کنید. پیش‌نمایش پایین صفحه با تغییرات شما به‌روزرسانی می‌شود.</p>
            </div>
        <div class="rc-grid">
            <div class="ui-card rc-editor-card">
                <h2 class="rc-h">عمومی</h2>
                <p class="rc-row"><label><input type="checkbox" name="rc_active" value="1" <?php checked(self::field('rc_active',false,$id));?>> فعال</label></p>
                <p class="rc-row">
                    <label>دستگاه</label><br>
                    <select name="rc_device">
                        <option value="both" <?php selected(self::field('rc_device','both',$id),'both');?>>هردو</option>
                        <option value="desktop" <?php selected(self::field('rc_device','both',$id),'desktop');?>>دسکتاپ</option>
                        <option value="mobile" <?php selected(self::field('rc_device','both',$id),'mobile');?>>موبایل</option>
                    </select>
                </p>
                <p class="rc-row rc-device-field rc-device-desktop"><label>لینک مقصد دسکتاپ</label><br>
                    <input type="url" name="rc_link_desktop" value="<?php echo esc_url(self::field('rc_link_desktop', self::field('rc_link','',$id), $id)); ?>" class="widefat" placeholder="https://example.com/?utm_source=..."></p>
                <p class="rc-row rc-device-field rc-device-mobile"><label>لینک مقصد موبایل</label><br>
                    <input type="url" name="rc_link_mobile" value="<?php echo esc_url(self::field('rc_link_mobile', self::field('rc_link','',$id), $id)); ?>" class="widefat" placeholder="در صورت خالی بودن، لینک دسکتاپ استفاده می‌شود"></p>

                <div class="rc-section-heading"><h2 class="rc-h">زمان‌بندی</h2><button type="button" class="button-link rc-clear-rules" id="rc_clear_rules">پاک‌کردن شرایط</button></div>
                <p class="rc-help-note">همه گزینه‌های این بخش اختیاری هستند؛ اگر خالی بمانند، محدودیتی برای نمایش بنر اعمال نمی‌شود.</p>
                <p class="rc-row"><label>شروع <span class="rc-optional">اختیاری</span> (Y-m-d H:i)</label><br>
                    <input type="text" name="rc_start" value="<?php echo $get('rc_start',''); ?>" placeholder="2025-08-18 08:00"></p>
                <p class="rc-row"><label>پایان <span class="rc-optional">اختیاری</span> (Y-m-d H:i)</label><br>
                    <input type="text" name="rc_end" value="<?php echo $get('rc_end',''); ?>" placeholder="2025-09-01 23:59"></p>
                <p class="rc-row"><label>روزهای هفته <span class="rc-optional">اختیاری</span> (0=Sun,...,6=Sat، مثل 0,1,2)</label><br>
                    <input type="text" name="rc_days" value="<?php echo $get('rc_days',''); ?>" placeholder="1,2,3,4,5"></p>
                <p class="rc-row"><label>بازه ساعت <span class="rc-optional">اختیاری</span> (HH:MM)</label><br>
                    <input type="text" name="rc_time_start" value="<?php echo $get('rc_time_start',''); ?>" placeholder="09:00">
                    <input type="text" name="rc_time_end" value="<?php echo $get('rc_time_end',''); ?>" placeholder="22:00">
                </p>

                <h2 class="rc-h">قوانین نمایش و فرکانس</h2>
                <p class="rc-row"><label>موقعیت</label><br>
                    <select name="rc_position">
                        <option value="tl" <?php selected($get('rc_position','br'),'tl');?>>بالا-چپ</option>
                        <option value="tr" <?php selected($get('rc_position','br'),'tr');?>>بالا-راست</option>
                        <option value="bl" <?php selected($get('rc_position','br'),'bl');?>>پایین-چپ</option>
                        <option value="br" <?php selected($get('rc_position','br'),'br');?>>پایین-راست</option>
                        <option value="center" <?php selected($get('rc_position','br'),'center');?>>مرکز</option>
                    </select>
                </p>
                <p class="rc-row"><label>وزن نمایش (برای چرخش تصادفی)</label><br>
                    <input type="number" name="rc_weight" min="1" value="<?php echo (int)$geti('rc_weight',1); ?>"></p>
                <p class="rc-row"><label>عدم نمایش پس از بستن (روز)</label><br>
                    <input type="number" name="rc_mute_days" min="0" value="<?php echo (int)$geti('rc_mute_days',0); ?>"></p>
                <p class="rc-row"><label>سقف نمایش روزانه برای هر کاربر</label><br>
                    <input type="number" name="rc_cap_user_day" min="0" value="<?php echo (int)$geti('rc_cap_user_day',0); ?>"></p>
                <p class="rc-row"><label>تأخیر نمایش (میلی‌ثانیه)</label><br>
                    <input type="number" name="rc_delay_ms" min="0" value="<?php echo (int)$geti('rc_delay_ms',0); ?>"></p>
                <p class="rc-row"><label>نمایش پس از اسکرول (%)</label><br>
                    <input type="number" name="rc_scroll_percent" min="0" max="100" value="<?php echo (int)$geti('rc_scroll_percent',0); ?>"></p>
                <p class="rc-row"><label><input type="checkbox" name="rc_exit_intent" value="1" <?php checked($getb('rc_exit_intent',false)); ?>> نمایش بر اساس خروج کاربر (Exit-Intent)</label></p>
            </div>

            <div class="ui-card rc-editor-card rc-media-card">
                <div class="rc-device-tabs" role="tablist" aria-label="تنظیمات دستگاه">
                    <button type="button" class="rc-device-tab is-active" role="tab" aria-selected="true" data-device-tab="desktop">دسکتاپ <span>تصویر و لینک</span></button>
                    <button type="button" class="rc-device-tab" role="tab" aria-selected="false" data-device-tab="mobile">موبایل <span>تصویر و لینک</span></button>
                </div>
                <h2 class="rc-h">رسانه و ظاهر</h2>
                <p class="rc-row rc-device-field rc-device-desktop"><label>تصویر دسکتاپ</label><br>
                    <img src="<?php echo esc_url($imgDurl);?>" class="rc-preview-img">
                    <input type="hidden" name="rc_image_desktop" value="<?php echo (int)$imgD;?>">
                    <button type="button" class="button rcp-media" data-target="rc_image_desktop">انتخاب/آپلود</button>
                </p>
                <p class="rc-row rc-device-field rc-device-mobile"><label>تصویر موبایل</label><br>
                    <img src="<?php echo esc_url($imgMurl);?>" class="rc-preview-img">
                    <input type="hidden" name="rc_image_mobile" value="<?php echo (int)$imgM;?>">
                    <button type="button" class="button rcp-media" data-target="rc_image_mobile">انتخاب/آپلود</button>
                </p>
                <p class="rc-row"><label>عرض (مثلاً 320px یا 80%)</label><br>
                    <input type="text" name="rc_width" value="<?php echo $get('rc_width','320px'); ?>" placeholder="320px"></p>
                <p class="rc-row"><label>فاصله X</label><br>
                    <input type="text" name="rc_offset_x" value="<?php echo $get('rc_offset_x','16px'); ?>" placeholder="16px"></p>
                <p class="rc-row"><label>فاصله Y</label><br>
                    <input type="text" name="rc_offset_y" value="<?php echo $get('rc_offset_y','16px'); ?>" placeholder="16px"></p>
                <p class="rc-row"><label>انحنای گوشه‌ها</label><br>
                    <input type="text" name="rc_radius" value="<?php echo $get('rc_radius','12px'); ?>" placeholder="12px"></p>
                <p class="rc-row"><label>انیمیشن ورود</label><br>
                    <select name="rc_anim_in">
                        <option value="fade" <?php selected($get('rc_anim_in','fade'),'fade');?>>محو شدن</option>
                        <option value="slide" <?php selected($get('rc_anim_in','fade'),'slide');?>>لغزش</option>
                        <option value="zoom" <?php selected($get('rc_anim_in','fade'),'zoom');?>>بزرگ‌نمایی</option>
                        <option value="bounce" <?php selected($get('rc_anim_in','fade'),'bounce');?>>جهش</option>
                    </select>
                </p>
                <p class="rc-row"><label>انیمیشن خروج</label><br>
                    <select name="rc_anim_out">
                        <option value="fade" <?php selected($get('rc_anim_out','fade'),'fade');?>>محو شدن</option>
                        <option value="slide" <?php selected($get('rc_anim_out','fade'),'slide');?>>لغزش</option>
                        <option value="zoom" <?php selected($get('rc_anim_out','fade'),'zoom');?>>بزرگ‌نمایی</option>
                        <option value="bounce" <?php selected($get('rc_anim_out','fade'),'bounce');?>>جهش</option>
                    </select>
                </p>

                <h2 class="rc-h">منبع ورودی و آدرس</h2>
                <p class="rc-help-note">این فیلترها نیز اختیاری هستند؛ خالی‌گذاشتن آن‌ها یعنی نمایش در همه صفحات و برای همه منابع.</p>
                <p class="rc-row"><label>الزام UTM Source <span class="rc-optional">اختیاری</span> (لیست جدا با کاما)</label><br>
                    <input type="text" name="rc_require_utm_source" value="<?php echo $get('rc_require_utm_source',''); ?>" placeholder="google,instagram"></p>
                <p class="rc-row"><label>Referrer باید شامل <span class="rc-optional">اختیاری</span> (کاما/خط جدید)</label><br>
                    <textarea name="rc_referrer_contains" rows="2" class="widefat" placeholder="facebook.com, telegram.me"><?php echo esc_textarea(self::field('rc_referrer_contains','',$id)); ?></textarea></p>
                <p class="rc-row"><label>شامل URLها <span class="rc-optional">اختیاری</span> (هر خط یا کاما یک عبارت)</label><br>
                    <textarea name="rc_include_urls" rows="2" class="widefat" placeholder="/blog/, /sale"><?php echo esc_textarea(self::field('rc_include_urls','',$id)); ?></textarea></p>
                <p class="rc-row"><label>حذف URLها <span class="rc-optional">اختیاری</span> (هر خط یا کاما یک عبارت)</label><br>
                    <textarea name="rc_exclude_urls" rows="2" class="widefat" placeholder="/checkout"><?php echo esc_textarea(self::field('rc_exclude_urls','',$id)); ?></textarea></p>
            </div>
        </div>

        <div class="ui-card rc-live">
            <h2 class="rc-h">پیش‌نمایش زنده</h2>
            <div id="rc_live_stage">
                <div class="rc-banner rc-pos-br rc-in-fade" style="width:320px;border-radius:12px;--rc-ox:16px;--rc-oy:16px;">
                    <button type="button" class="rc-close" aria-label="بستن پیش‌نمایش">×</button>
                    <img id="rc_live_img" src="<?php echo esc_url($imgDurl); ?>" alt="preview">
                </div>
            </div>
            <p class="description">پیش‌نمایش صرفاً نمایهٔ ظاهری است و قوانین نمایش/تریگرها را شبیه‌سازی نمی‌کند.</p>
        </div>
        </div>
<?php
    }

    public static function save_meta($post_id) {
        if (get_post_type($post_id) !== RCP_Post_Type::CPT) return;
        if (!isset($_POST['rc_nonce']) || !wp_verify_nonce($_POST['rc_nonce'], 'rc_save_meta')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $b = function($k){ return isset($_POST[$k]) ? (bool)$_POST[$k] : false; };
        $s = function($k,$def=''){ return isset($_POST[$k]) ? sanitize_text_field($_POST[$k]) : $def; };
        $i = function($k){ return isset($_POST[$k]) ? max(0, (int)$_POST[$k]) : 0; };
        $t = function($k){ return isset($_POST[$k]) ? sanitize_textarea_field(wp_unslash($_POST[$k])) : ''; };
        $css = function($k, $default) use ($s) {
            $value = trim($s($k, $default));
            return preg_match('/^(?:0|(?:\d+(?:\.\d+)?)(?:px|rem|em|vw|vh|%))$/', $value) ? $value : $default;
        };

        update_post_meta($post_id,'rc_active', $b('rc_active'));
        update_post_meta($post_id,'rc_device', in_array($s('rc_device','both'),['desktop','mobile','both'])? $s('rc_device','both'):'both');
        update_post_meta($post_id,'rc_image_desktop', $i('rc_image_desktop'));
        update_post_meta($post_id,'rc_image_mobile',  $i('rc_image_mobile'));
        update_post_meta($post_id,'rc_link', esc_url_raw($s('rc_link','')));
        update_post_meta($post_id,'rc_link_desktop', esc_url_raw($s('rc_link_desktop', $s('rc_link',''))));
        update_post_meta($post_id,'rc_link_mobile', esc_url_raw($s('rc_link_mobile', $s('rc_link',''))));

        update_post_meta($post_id,'rc_start', $s('rc_start',''));
        update_post_meta($post_id,'rc_end',   $s('rc_end',''));
        update_post_meta($post_id,'rc_days',  $s('rc_days',''));
        update_post_meta($post_id,'rc_time_start',$s('rc_time_start',''));
        update_post_meta($post_id,'rc_time_end',  $s('rc_time_end',''));

        update_post_meta($post_id,'rc_position', in_array($s('rc_position','br'),['tl','tr','bl','br','center'])? $s('rc_position','br'):'br');
        update_post_meta($post_id,'rc_width',  $css('rc_width','320px'));
        update_post_meta($post_id,'rc_offset_x',$css('rc_offset_x','16px'));
        update_post_meta($post_id,'rc_offset_y',$css('rc_offset_y','16px'));
        update_post_meta($post_id,'rc_radius', $css('rc_radius','12px'));
        update_post_meta($post_id,'rc_weight', max(1, $i('rc_weight')));

        update_post_meta($post_id,'rc_include_urls', $t('rc_include_urls'));
        update_post_meta($post_id,'rc_exclude_urls', $t('rc_exclude_urls'));
        update_post_meta($post_id,'rc_referrer_contains', $t('rc_referrer_contains'));
        update_post_meta($post_id,'rc_require_utm_source', $s('rc_require_utm_source',''));

        update_post_meta($post_id,'rc_cap_user_day', $i('rc_cap_user_day'));
        update_post_meta($post_id,'rc_mute_days',    $i('rc_mute_days'));
        update_post_meta($post_id,'rc_delay_ms',     $i('rc_delay_ms'));
        update_post_meta($post_id,'rc_scroll_percent', min(100, $i('rc_scroll_percent')));
        update_post_meta($post_id,'rc_exit_intent',  $b('rc_exit_intent'));

        update_post_meta($post_id,'rc_anim_in',  in_array($s('rc_anim_in','fade'),['fade','slide','zoom','bounce'])? $s('rc_anim_in','fade'):'fade');
        update_post_meta($post_id,'rc_anim_out', in_array($s('rc_anim_out','fade'),['fade','slide','zoom','bounce'])? $s('rc_anim_out','fade'):'fade');
        delete_transient('rc_candidates_base');
    }

    public static function utm_builder_page() {
        add_submenu_page(
            'edit.php?post_type=' . RCP_Post_Type::CPT,
            __('UTM Builder', 'ready-campaign'),
            __('UTM Builder', 'ready-campaign'),
            'edit_posts',
            'rc-utm-builder',
            [__CLASS__, 'utm_builder_render']
        );
    }

    public static function utm_builder_render() {
        if (!current_user_can('edit_posts')) return;
        $nonce = wp_create_nonce('rc_admin_nonce');

        $banners = get_posts([
            'post_type' => RCP_Post_Type::CPT,
            'numberposts' => -1,
            'post_status' => 'any',
            'orderby' => 'title',
            'order' => 'ASC',
        ]);
?>
<div class="wrap rc-admin-shell rc-utm-page">
    <div class="rc-page-heading">
        <div><span class="rc-eyebrow">CAMPAIGN TOOLKIT · UTM</span><h1>لینک‌ساز کمپین</h1><p>برای هر کانال یک لینک قابل‌اندازه‌گیری بسازید و مستقیم روی بنر قرار دهید.</p></div>
        <span class="rc-heading-mark" aria-hidden="true">↗</span>
    </div>
    <div class="rc-utm ui-card">
        <div class="rc-utm-grid">
            <label>آدرس پایه
                <input type="url" id="rc_base" placeholder="https://example.com/">
            </label>
            <label>utm_source <input type="text" id="rc_source" placeholder="google"></label>
            <label>utm_medium <input type="text" id="rc_medium" placeholder="cpc"></label>
            <label>utm_campaign <input type="text" id="rc_campaign" placeholder="summer_sale"></label>
            <label>utm_id <input type="text" id="rc_id" placeholder="id-123"></label>
            <label>utm_term <input type="text" id="rc_term" placeholder="keyword"></label>
            <label>utm_content <input type="text" id="rc_content" placeholder="banner_a"></label>
        </div>
        <div class="rc-utm-actions">
            <button type="button" class="button button-primary" id="rc_build">ساخت لینک</button>
            <input type="text" id="rc_result" readonly placeholder="لینک نهایی اینجا نمایش داده می‌شود" class="widefat">
            <button type="button" class="button" id="rc_copy">کپی لینک</button>
        </div>
        <hr>
        <div class="rc-utm-apply">
            <label>اعمال روی بنر:
                <select id="rc_banner">
                    <option value="">— انتخاب بنر —</option>
                    <?php foreach($banners as $b): ?>
                        <option value="<?php echo (int)$b->ID; ?>"><?php echo esc_html($b->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button type="button" class="button button-secondary" id="rc_apply_desktop">اعمال روی بنر دسکتاپ</button>
            <button type="button" class="button button-secondary" id="rc_apply_mobile">اعمال روی بنر موبایل</button>
        </div>
    </div>
</div>
<script>window.RCAdmin = Object.assign(window.RCAdmin||{}, {nonce:'<?php echo esc_js($nonce); ?>'});</script>
<?php
    }

    public static function ajax_apply_utm() {
        check_ajax_referer('rc_admin_nonce','nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error(['message'=>'no perms'], 403);

        $banner_id = isset($_POST['banner_id']) ? (int)$_POST['banner_id'] : 0;
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        $device = isset($_POST['device']) ? sanitize_key($_POST['device']) : 'link';
        if (!$banner_id || empty($url) || get_post_type($banner_id) !== RCP_Post_Type::CPT || !current_user_can('edit_post', $banner_id)) wp_send_json_error(['message'=>'invalid'], 400);

        $meta_key = in_array($device, ['desktop', 'mobile'], true) ? 'rc_link_' . $device : 'rc_link';
        update_post_meta($banner_id, $meta_key, $url);
        wp_send_json_success(['message'=>'updated']);
    }
}
